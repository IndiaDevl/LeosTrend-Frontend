import React, { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { getOptimizedImageUrl } from "../utils/api";
import "./HeroSlider.css";

const SLIDES = [
  { img: "https://i.ibb.co/bjfzLFMD/banner-1.png" },
  { img: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?q=80&w=1600" },
  { img: "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?q=80&w=1600" },
  { img: "https://images.unsplash.com/photo-1489987707025-afc232f7ea0f?q=80&w=1600" },
];

export default function HeroSlider() {
  const [current, setCurrent] = useState(0);
  const [isMobileViewport, setIsMobileViewport] = useState(() => {
    if (typeof window === "undefined") return false;
    return window.matchMedia("(max-width: 640px)").matches;
  });
  const [isHeroVisible, setIsHeroVisible] = useState(true);
  const [isDocumentVisible, setIsDocumentVisible] = useState(() => {
    if (typeof document === "undefined") return true;
    return document.visibilityState === "visible";
  });
  const sectionRef = useRef(null);
  const stripRef = useRef(null);
  const panelImgRef = useRef(null);
  const timerRef = useRef(null);
  const isAutoPlayEnabled = isHeroVisible && isDocumentVisible;

  useEffect(() => {
    if (typeof window === "undefined") return undefined;

    const mediaQuery = window.matchMedia("(max-width: 640px)");
    const handleChange = (event) => setIsMobileViewport(event.matches);

    setIsMobileViewport(mediaQuery.matches);
    mediaQuery.addEventListener("change", handleChange);
    return () => mediaQuery.removeEventListener("change", handleChange);
  }, []);

  useEffect(() => {
    if (typeof document === "undefined") return undefined;

    const handleVisibilityChange = () => {
      setIsDocumentVisible(document.visibilityState === "visible");
    };

    document.addEventListener("visibilitychange", handleVisibilityChange);
    return () => document.removeEventListener("visibilitychange", handleVisibilityChange);
  }, []);

  useEffect(() => {
    if (typeof IntersectionObserver === "undefined" || !sectionRef.current) return undefined;

    const observer = new IntersectionObserver(
      ([entry]) => {
        setIsHeroVisible(entry.isIntersecting);
      },
      { threshold: 0.2 }
    );

    observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  const getHeroImage = (img, width) => getOptimizedImageUrl(img, { width, height: 1000 });

  const goTo = (n) => {
    const next = (n + SLIDES.length) % SLIDES.length;
    setCurrent(next);
    if (panelImgRef.current) {
      panelImgRef.current.style.opacity = "0";
      setTimeout(() => {
        if (panelImgRef.current) {
          panelImgRef.current.src = getHeroImage(SLIDES[next].img, 900);
          panelImgRef.current.style.opacity = "1";
        }
      }, 300);
    }
    resetStrip();
  };

  const resetStrip = () => {
    if (!stripRef.current) return;
    stripRef.current.style.transition = "none";
    stripRef.current.style.height = "0%";
    setTimeout(() => {
      if (stripRef.current) {
        stripRef.current.style.transition = "height 5s linear";
        stripRef.current.style.height = "100%";
      }
    }, 50);
  };

  const startAuto = () => {
    clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setCurrent((p) => (p + 1) % SLIDES.length);
    }, 5000);
  };

  useEffect(() => {
    if (!isAutoPlayEnabled) {
      clearInterval(timerRef.current);
      return undefined;
    }

    resetStrip();
    startAuto();
    return () => clearInterval(timerRef.current);
  }, [isAutoPlayEnabled]);

  useEffect(() => {
    if (isAutoPlayEnabled) {
      resetStrip();
    }
  }, [current, isAutoPlayEnabled]);

  const handleNav = (dir) => {
    goTo(current + dir);
    if (isAutoPlayEnabled) startAuto();
  };

  const handleShopNow = () => {
    if (typeof document === "undefined") return;

    const categorySection = document.getElementById("shop-category-section");
    if (!categorySection) return;

    categorySection.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <section className="hero" ref={sectionRef}>

      {/* ── Slides ── */}
      <div className="hero-slider">
        <div className="hero-slide active">
          <img
            src={getHeroImage(SLIDES[current].img, isMobileViewport ? 900 : 1600)}
            alt="LeosTrend collection"
            className="hero-image"
            loading="eager"
            fetchPriority="high"
            decoding="async"
          />
        </div>
      </div>

      {/* ── Vertical progress strip ── */}
      <div className="slide-strip">
        <div className="slide-strip-fill" ref={stripRef} />
      </div>

      {/* ── Content ── */}
      <div className="hero-content">
        <div className="hero-content-inner">

          <div className="hero-eyebrow">
            <div className="eyebrow-line" />
            <p className="hero-kicker">New Arrivals</p>
          </div>

          <h1 className="hero-title">
            Easy Tees,<br /><em>Everyday Wear</em>
          </h1>

          <p className="hero-subtitle">
            Soft oversized tees for daily wear.
          </p>

          <div className="hero-actions">
            <button type="button" className="hero-btn primary" onClick={handleShopNow}>
              <span>Shop Now</span>
              <span className="btn-arrow">→</span>
            </button>
            <Link to="/about" className="hero-btn secondary">Our Story</Link>
          </div>

          <div className="hero-stats">
            <div className="stat-item">
              <span className="stat-num">50+</span>
              <span className="stat-label">Happy Customers</span>
            </div>
            <div className="stat-item">
              <span className="stat-num">48hr</span>
              <span className="stat-label">Fast Dispatch</span>
            </div>
            <div className="stat-item">
              <span className="stat-num">100%</span>
              <span className="stat-label">Premium Fabric</span>
            </div>
          </div>

        </div>
      </div>

      {/* ── Right image panel ── */}
      {!isMobileViewport && (
        <div className="hero-image-panel">
          <img
            ref={panelImgRef}
            className="panel-img"
            src={getHeroImage(SLIDES[0].img, 900)}
            alt="Featured look"
            loading="eager"
            decoding="async"
            style={{ transition: "opacity 0.5s ease" }}
          />
          <div className="panel-overlay" />
        </div>
      )}

      {/* ── Nav: prev · dots · next ── */}
      <div className="hero-nav">
        <button className="hero-arrow" onClick={() => handleNav(-1)}>‹</button>
        <div className="hero-dots">
          {SLIDES.map((_, i) => (
            <span
              key={i}
              role="button"
              aria-label={`Go to slide ${i + 1}`}
              className={`dot${i === current ? " active" : ""}`}
              onClick={() => { goTo(i); startAuto(); }}
            />
          ))}
        </div>
        <button className="hero-arrow" onClick={() => handleNav(1)}>›</button>
      </div>

      {/* ── Slide counter ── */}
      <div className="hero-counter">
        <strong>{String(current + 1).padStart(2, "0")}</strong>
        <span className="counter-sep"> / </span>
        {String(SLIDES.length).padStart(2, "0")}
      </div>

      {/* ── Float tags ── */}
      <div className="hero-float-tags">
        <span className="float-tag">Limited Drops</span>
        <span className="float-tag">Premium Fabric</span>
        <span className="float-tag">Fast Delivery</span>
      </div>

    </section>
  );
}